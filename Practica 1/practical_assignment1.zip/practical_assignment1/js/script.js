(function() {
    var app = angular.module('AttractionsModule', []);
    var controller = app.controller('AttractionsController', ($scope) => {
        /** TO DO
            Complete all required code to complete the functionality of the application
        */
    });

}());
